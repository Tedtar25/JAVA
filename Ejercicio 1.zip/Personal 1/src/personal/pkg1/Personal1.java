/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package personal.pkg1;

import java.util.Scanner;

/**
 * Este programa es una calculadora que permite calcular el total de una compra
 * de varios items, incluyendo la suma total y descuentos si es necesario.
 * 
 * El usuario debe ingresar la cantidad y el precio unitario de cada item.
 * Luego, puede indicar si desea aplicar un descuento y en caso afirmativo, 
 * el porcentaje de descuento a aplicar.
 * 
 * Finalmente, el programa muestra el total de la compra, el total con el
 * descuento aplicado (si corresponde) y la cantidad del descuento.
 * 
 * @author Cesar Carrillo
 */
public class Personal1 {

    static Scanner sn = new Scanner(System.in);

    public static void main(String[] args) {
        double contador = 0;
        double total, totalDescontado;
        System.out.println("Cuantos items?");
        int items = sn.nextInt();
        for (int i = 0; i < items; i++) {
            System.out.println("Cantidad del item " + (i + 1) + "?");
            int cantidad = sn.nextInt();
            System.out.println("Precio Unitario?");
            double precio = sn.nextDouble();
            contador += (precio * cantidad);
        }

        System.out.println("Hay descuento por calcular?");
        String descuento = sn.next();
        if (descuento.equalsIgnoreCase("si")) {
            System.out.println("De cuanto es el descuento?");
            double porcentaje = sn.nextDouble();
            double descuentoCalculado = (porcentaje / 100) * contador;
            totalDescontado = contador - descuentoCalculado;
            System.out.println("El total es: $" + contador);
            System.out.println("El total con el " + porcentaje + "% de descuento es: $" + totalDescontado);
            System.out.println("La cantidad del descuento es: $" + descuentoCalculado);

        } else {
            System.out.println("El total es: $" + contador + " sin descuento.");
        }
    }
}

